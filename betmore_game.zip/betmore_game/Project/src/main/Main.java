package betmore_game;

/**
 * Initiate a new game.
 */
public class Main {

	public static void main(String[] args) {
		new Game_Chair();

	}

}
