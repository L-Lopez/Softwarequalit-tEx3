Bet More Game

A game to pick a random card with a value and compare it to to the games card value.